package com.iabot.api

fun main(args: Array<String>) {
    val ElementSystem = ElementSystem()
    ElementSystem.start()
}